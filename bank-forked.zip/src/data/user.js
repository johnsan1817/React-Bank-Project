const users = [
  // {
  //   userPic: "/images/Avatar0.png",
  //   name: "Kuta",
  //   email: "kutta@gmail.com",
  //   password: "secret",
  //   balance: 100,
  //   transactionHistory: [],
  // },
];

export default users;
