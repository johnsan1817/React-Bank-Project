const users = [
  // {
  //   userPic: "/images/Avatar0.png",
  //   name: "raj",
  //   email: "rajhari@.com",
  //   balance: 100,
  //   transactionHistory: [],
  // },
];
//Regarding the "user.js" file, it is not a standard term//

export default users;
