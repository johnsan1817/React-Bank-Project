import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import useUserContext from "../hooks/useUserContext";

import RegisterPopUp from "./popups/RegisterPopUp";
import LoginPopUp from "./popups/LoginPopup";

const Navbar = () => {
  const [isRegisterPopUp, setIsRegiterPopUp] = useState(false);
  const [isLoginPopUp, setIsLoginPopUp] = useState(false);
  const { setLoggedInUser } = useUserContext();
  const navigate = useNavigate();

  const toggleRegisterPopUp = () => {
    setIsRegiterPopUp(!isRegisterPopUp);
  };

  const toggleLoginPopUp = () => {
    setIsLoginPopUp(!isLoginPopUp);
  };

  const handleLogout = () => {
    setLoggedInUser("");
    navigate("/");
  };

  const handleHomeClick = () => {
    navigate("/");
  };

  return (
    <>
      <div className="navbars">
        <nav className="navbar navbar-expand-lg bg-primary">
          <div className="container-fluid">
            <span className="navbar-brand" onClick={handleHomeClick}>
              CLASSIC Bank
            </span>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <Link to="/" className="nav-link" exact>
                    Home
                  </Link>
                </li>
                <li className="nav-item">
                  <span
                    onClick={toggleRegisterPopUp}
                    className="nav-link clickable"
                  >
                    Create Account
                  </span>
                </li>
                <li className="nav-item">
                  <span
                    onClick={toggleLoginPopUp}
                    className="nav-link clickable"
                  >
                    Login
                  </span>
                </li>
                <li className="nav-item">
                  <Link to="/deposit" className="nav-link">
                    Deposit
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/withdraw" className="nav-link">
                    Withdraw
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/allData" className="nav-link">
                    All Data
                  </Link>
                </li>
                <li className="nav-item">
                  <Link to="/myAccount" className="nav-link">
                    My Account
                  </Link>
                </li>
                <li className="nav-item">
                  <span onClick={handleLogout} className="nav-link clickable">
                    Logout
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        {isRegisterPopUp && <RegisterPopUp handleClose={toggleRegisterPopUp} />}
        {isLoginPopUp && <LoginPopUp handleClose={toggleLoginPopUp} />}
      </div>
    </>
  );
};

export default Navbar;
