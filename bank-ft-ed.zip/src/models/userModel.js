class User {
  constructor(userPic, name, email, balance, transactionHistory) {
    this.userPic = userPic;
    this.name = name;
    this.email = email;

    this.balance = balance;
    this.transactionHistory = transactionHistory;
  }
}

export default User;
