import { useContext } from "react";
import UserContext from "../context/UserContext";

const useUserContext = () => {
  return useContext(UserContext);
};
//Profile component consumes the user context using the useContext hook. It retrieves the user object from the context and displays the user's name and account balance.//
export default useUserContext;
